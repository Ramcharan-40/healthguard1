/*
  # Preventive Health Tracking System

  ## Overview
  This migration creates the database schema for a preventive healthcare tracking application
  that enables users to log daily health metrics, track trends, and receive preventive insights.

  ## New Tables

  ### 1. `profiles`
  User profile information and gamification stats
  - `id` (uuid, primary key, references auth.users)
  - `email` (text)
  - `full_name` (text)
  - `current_streak` (integer, default 0)
  - `longest_streak` (integer, default 0)
  - `total_points` (integer, default 0)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. `health_logs`
  Daily health metrics logged by users
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `log_date` (date)
  - `sleep_hours` (numeric, 0-24)
  - `water_intake` (numeric, glasses)
  - `steps` (integer)
  - `mood_score` (integer, 1-10)
  - `stress_level` (integer, 1-10)
  - `notes` (text, optional)
  - `created_at` (timestamptz)

  ### 3. `insights`
  Preventive health insights generated for users
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `insight_type` (text: 'warning', 'tip', 'achievement')
  - `title` (text)
  - `message` (text)
  - `risk_level` (text: 'low', 'medium', 'high')
  - `is_read` (boolean, default false)
  - `created_at` (timestamptz)

  ### 4. `badges`
  Achievement badges earned by users
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `badge_type` (text: 'first_log', 'week_streak', 'month_streak', 'water_champion', etc.)
  - `badge_name` (text)
  - `earned_at` (timestamptz)

  ## Security
  - Enable RLS on all tables
  - Users can only access their own data
  - Authenticated users required for all operations
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  current_streak integer DEFAULT 0,
  longest_streak integer DEFAULT 0,
  total_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create health_logs table
CREATE TABLE IF NOT EXISTS health_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  log_date date NOT NULL,
  sleep_hours numeric CHECK (sleep_hours >= 0 AND sleep_hours <= 24),
  water_intake numeric DEFAULT 0,
  steps integer DEFAULT 0,
  mood_score integer CHECK (mood_score >= 1 AND mood_score <= 10),
  stress_level integer CHECK (stress_level >= 1 AND stress_level <= 10),
  notes text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, log_date)
);

-- Create insights table
CREATE TABLE IF NOT EXISTS insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  insight_type text NOT NULL CHECK (insight_type IN ('warning', 'tip', 'achievement')),
  title text NOT NULL,
  message text NOT NULL,
  risk_level text CHECK (risk_level IN ('low', 'medium', 'high')),
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create badges table
CREATE TABLE IF NOT EXISTS badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  badge_type text NOT NULL,
  badge_name text NOT NULL,
  earned_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE health_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE badges ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Health logs policies
CREATE POLICY "Users can view own health logs"
  ON health_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own health logs"
  ON health_logs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own health logs"
  ON health_logs FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own health logs"
  ON health_logs FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insights policies
CREATE POLICY "Users can view own insights"
  ON insights FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own insights"
  ON insights FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own insights"
  ON insights FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Badges policies
CREATE POLICY "Users can view own badges"
  ON badges FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own badges"
  ON badges FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS health_logs_user_date_idx ON health_logs(user_id, log_date DESC);
CREATE INDEX IF NOT EXISTS insights_user_created_idx ON insights(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS badges_user_earned_idx ON badges(user_id, earned_at DESC);