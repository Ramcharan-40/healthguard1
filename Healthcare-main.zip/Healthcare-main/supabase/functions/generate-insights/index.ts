import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface HealthLog {
  log_date: string;
  sleep_hours: number | null;
  water_intake: number | null;
  steps: number | null;
  mood_score: number | null;
  stress_level: number | null;
}

interface Insight {
  insight_type: 'warning' | 'tip' | 'achievement';
  title: string;
  message: string;
  risk_level: 'low' | 'medium' | 'high' | null;
}

function analyzeHealthTrends(logs: HealthLog[]): Insight[] {
  if (logs.length < 3) return [];

  const insights: Insight[] = [];
  const recent = logs.slice(0, 3);

  const avgSleep = recent.reduce((sum, log) => sum + (log.sleep_hours || 0), 0) / recent.length;
  if (avgSleep < 6) {
    insights.push({
      insight_type: 'warning',
      title: 'Low Sleep Detected',
      message: `You have averaged ${avgSleep.toFixed(1)} hours of sleep over the last 3 days. Less than 6 hours can lead to fatigue and weakened immunity. Try to sleep before midnight tonight.`,
      risk_level: 'high',
    });
  } else if (avgSleep < 7) {
    insights.push({
      insight_type: 'tip',
      title: 'Sleep Could Be Better',
      message: `Your average sleep is ${avgSleep.toFixed(1)} hours. Aim for 7-9 hours to optimize recovery and energy levels.`,
      risk_level: 'medium',
    });
  }

  const avgWater = recent.reduce((sum, log) => sum + (log.water_intake || 0), 0) / recent.length;
  if (avgWater < 6) {
    insights.push({
      insight_type: 'tip',
      title: 'Hydration Reminder',
      message: `You are averaging ${avgWater.toFixed(1)} glasses of water daily. Try to reach 8 glasses to stay properly hydrated and maintain energy.`,
      risk_level: 'medium',
    });
  }

  const avgSteps = recent.reduce((sum, log) => sum + (log.steps || 0), 0) / recent.length;
  if (avgSteps < 5000) {
    insights.push({
      insight_type: 'tip',
      title: 'Low Activity Level',
      message: `Your daily step average is ${Math.round(avgSteps)}. Try a 30-minute walk to boost circulation and mood. Even small increases help!`,
      risk_level: 'medium',
    });
  }

  const avgStress = recent.reduce((sum, log) => sum + (log.stress_level || 0), 0) / recent.length;
  if (avgStress >= 8) {
    insights.push({
      insight_type: 'warning',
      title: 'High Stress Levels',
      message: `Your stress has been high (${avgStress.toFixed(1)}/10) for 3 days. Consider taking breaks, practicing deep breathing, or talking to someone. Chronic stress affects heart health.`,
      risk_level: 'high',
    });
  } else if (avgStress >= 6) {
    insights.push({
      insight_type: 'tip',
      title: 'Elevated Stress',
      message: `Stress levels are moderate (${avgStress.toFixed(1)}/10). Try meditation, exercise, or a hobby to manage stress before it escalates.`,
      risk_level: 'medium',
    });
  }

  const avgMood = recent.reduce((sum, log) => sum + (log.mood_score || 0), 0) / recent.length;
  if (avgMood <= 4) {
    insights.push({
      insight_type: 'warning',
      title: 'Low Mood Pattern',
      message: `Your mood has been low (${avgMood.toFixed(1)}/10) recently. Consider reaching out to friends, getting sunlight, or speaking with a counselor if this persists.`,
      risk_level: 'high',
    });
  }

  if (avgSleep >= 7.5 && avgWater >= 8 && avgSteps >= 8000 && avgStress <= 4 && avgMood >= 7) {
    insights.push({
      insight_type: 'achievement',
      title: 'Excellent Health Routine!',
      message: 'You are maintaining great habits across all metrics. Keep it up to prevent future health issues!',
      risk_level: 'low',
    });
  }

  return insights;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data: logs } = await supabase
      .from('health_logs')
      .select('*')
      .eq('user_id', user.id)
      .order('log_date', { ascending: false })
      .limit(7);

    if (!logs || logs.length === 0) {
      return new Response(
        JSON.stringify({ message: 'Not enough data yet', insights: [] }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const insights = analyzeHealthTrends(logs);

    await supabase.from('insights').delete().eq('user_id', user.id).eq('is_read', false);

    if (insights.length > 0) {
      const insightsToInsert = insights.map(insight => ({
        user_id: user.id,
        ...insight,
      }));
      await supabase.from('insights').insert(insightsToInsert);
    }

    const logCount = logs.length;
    let streakDays = 0;
    let currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    for (const log of logs) {
      const logDate = new Date(log.log_date);
      logDate.setHours(0, 0, 0, 0);
      
      const diffTime = currentDate.getTime() - logDate.getTime();
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays === streakDays) {
        streakDays++;
      } else {
        break;
      }
    }

    const points = logCount * 10 + streakDays * 5;

    await supabase
      .from('profiles')
      .update({
        current_streak: streakDays,
        longest_streak: streakDays,
        total_points: points,
        updated_at: new Date().toISOString(),
      })
      .eq('id', user.id);

    return new Response(
      JSON.stringify({ 
        message: 'Insights generated successfully', 
        insights,
        streak: streakDays,
        points 
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});