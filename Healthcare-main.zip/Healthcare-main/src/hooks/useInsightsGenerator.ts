import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

export function useInsightsGenerator() {
  const { user } = useAuth();
  const [isGenerating, setIsGenerating] = useState(false);

  const generateInsights = async () => {
    if (!user) return;

    setIsGenerating(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-insights`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to generate insights');
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error generating insights:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    if (user) {
      generateInsights();
    }
  }, [user]);

  return { generateInsights, isGenerating };
}
