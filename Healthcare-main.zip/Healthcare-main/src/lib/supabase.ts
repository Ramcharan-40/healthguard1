import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  current_streak: number;
  longest_streak: number;
  total_points: number;
  created_at: string;
  updated_at: string;
}

export interface HealthLog {
  id: string;
  user_id: string;
  log_date: string;
  sleep_hours: number | null;
  water_intake: number | null;
  steps: number | null;
  mood_score: number | null;
  stress_level: number | null;
  notes: string | null;
  created_at: string;
}

export interface Insight {
  id: string;
  user_id: string;
  insight_type: 'warning' | 'tip' | 'achievement';
  title: string;
  message: string;
  risk_level: 'low' | 'medium' | 'high' | null;
  is_read: boolean;
  created_at: string;
}

export interface Badge {
  id: string;
  user_id: string;
  badge_type: string;
  badge_name: string;
  earned_at: string;
}
