import { useEffect, useState } from 'react';
import { supabase, Profile, HealthLog, Insight } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { HealthLogForm } from './HealthLogForm';
import { useInsightsGenerator } from '../hooks/useInsightsGenerator';
import { Heart, Plus, TrendingUp, Flame, Award, Moon, Droplets, Activity, Smile, Brain, LogOut } from 'lucide-react';

export function Dashboard() {
  const { user, signOut } = useAuth();
  const { generateInsights } = useInsightsGenerator();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [recentLogs, setRecentLogs] = useState<HealthLog[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);
  const [showLogForm, setShowLogForm] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    if (!user) return;

    try {
      const [profileRes, logsRes, insightsRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
        supabase
          .from('health_logs')
          .select('*')
          .eq('user_id', user.id)
          .order('log_date', { ascending: false })
          .limit(7),
        supabase
          .from('insights')
          .select('*')
          .eq('user_id', user.id)
          .eq('is_read', false)
          .order('created_at', { ascending: false })
          .limit(5),
      ]);

      if (profileRes.data) setProfile(profileRes.data);
      if (logsRes.data) setRecentLogs(logsRes.data);
      if (insightsRes.data) setInsights(insightsRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTodayLog = () => {
    const today = new Date().toISOString().split('T')[0];
    return recentLogs.find((log) => log.log_date === today);
  };

  const getAverages = () => {
    if (recentLogs.length === 0)
      return { sleep: 0, water: 0, steps: 0, mood: 0, stress: 0 };

    const totals = recentLogs.reduce(
      (acc, log) => ({
        sleep: acc.sleep + (log.sleep_hours || 0),
        water: acc.water + (log.water_intake || 0),
        steps: acc.steps + (log.steps || 0),
        mood: acc.mood + (log.mood_score || 0),
        stress: acc.stress + (log.stress_level || 0),
      }),
      { sleep: 0, water: 0, steps: 0, mood: 0, stress: 0 }
    );

    const count = recentLogs.length;
    return {
      sleep: (totals.sleep / count).toFixed(1),
      water: (totals.water / count).toFixed(1),
      steps: Math.round(totals.steps / count),
      mood: (totals.mood / count).toFixed(1),
      stress: (totals.stress / count).toFixed(1),
    };
  };

  const getRiskColor = (level: string | null) => {
    switch (level) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-green-100 text-green-800 border-green-200';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  const todayLog = getTodayLog();
  const averages = getAverages();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">PreventCare</h1>
              <p className="text-sm text-gray-600">Welcome back, {profile?.full_name || 'there'}</p>
            </div>
          </div>
          <button
            onClick={() => signOut()}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-3 mb-2">
              <Flame className="w-5 h-5 text-orange-500" />
              <h3 className="font-semibold text-gray-900">Current Streak</h3>
            </div>
            <p className="text-3xl font-bold text-gray-900">{profile?.current_streak || 0}</p>
            <p className="text-sm text-gray-600 mt-1">days in a row</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-5 h-5 text-blue-500" />
              <h3 className="font-semibold text-gray-900">Total Points</h3>
            </div>
            <p className="text-3xl font-bold text-gray-900">{profile?.total_points || 0}</p>
            <p className="text-sm text-gray-600 mt-1">keep it up!</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-500" />
              <h3 className="font-semibold text-gray-900">Logs Recorded</h3>
            </div>
            <p className="text-3xl font-bold text-gray-900">{recentLogs.length}</p>
            <p className="text-sm text-gray-600 mt-1">last 7 days</p>
          </div>
        </div>

        {!todayLog && (
          <div className="bg-blue-600 text-white rounded-xl p-6 mb-8 shadow-lg">
            <h2 className="text-xl font-semibold mb-2">Log Today's Health</h2>
            <p className="mb-4 opacity-90">
              Take 2 minutes to track your health and maintain your streak!
            </p>
            <button
              onClick={() => setShowLogForm(true)}
              className="bg-white text-blue-600 px-6 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Log Now
            </button>
          </div>
        )}

        {insights.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Preventive Insights
            </h2>
            <div className="space-y-3">
              {insights.map((insight) => (
                <div
                  key={insight.id}
                  className={`p-4 rounded-lg border ${getRiskColor(insight.risk_level)}`}
                >
                  <h3 className="font-semibold mb-1">{insight.title}</h3>
                  <p className="text-sm">{insight.message}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">7-Day Averages</h2>
            {todayLog && (
              <button
                onClick={() => setShowLogForm(true)}
                className="text-blue-600 hover:text-blue-700 font-medium text-sm flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                Add Log
              </button>
            )}
          </div>

          {recentLogs.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600 mb-4">No health logs yet</p>
              <button
                onClick={() => setShowLogForm(true)}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Log Your First Entry
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Moon className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{averages.sleep}</p>
                <p className="text-sm text-gray-600">hrs sleep</p>
              </div>

              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Droplets className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{averages.water}</p>
                <p className="text-sm text-gray-600">glasses</p>
              </div>

              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Activity className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{averages.steps}</p>
                <p className="text-sm text-gray-600">steps</p>
              </div>

              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Smile className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{averages.mood}</p>
                <p className="text-sm text-gray-600">mood</p>
              </div>

              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Brain className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-gray-900">{averages.stress}</p>
                <p className="text-sm text-gray-600">stress</p>
              </div>
            </div>
          )}
        </div>

        {recentLogs.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm p-6 mt-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Logs</h2>
            <div className="space-y-3">
              {recentLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <p className="font-medium text-gray-900">
                      {new Date(log.log_date).toLocaleDateString('en-US', {
                        weekday: 'short',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </p>
                    <p className="text-sm text-gray-600">
                      {log.sleep_hours}h sleep · {log.water_intake} glasses · {log.steps} steps
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                      Mood: {log.mood_score}/10
                    </span>
                    <span className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded">
                      Stress: {log.stress_level}/10
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {showLogForm && (
        <HealthLogForm
          onClose={() => setShowLogForm(false)}
          onSuccess={fetchDashboardData}
        />
      )}
    </div>
  );
}
